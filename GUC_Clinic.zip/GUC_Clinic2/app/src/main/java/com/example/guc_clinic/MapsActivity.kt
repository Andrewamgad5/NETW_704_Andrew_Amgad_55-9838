package com.example.guc_clinic

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var map: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap

        // Add markers for GUC clinic and drug stores
        val clinicLocation = LatLng(30.123456, 31.987654) // Replace with actual coordinates
        map.addMarker(MarkerOptions().position(clinicLocation).title("GUC Clinic"))
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(clinicLocation, 15f))

        // You can add more markers for drug stores similarly
    }
}
