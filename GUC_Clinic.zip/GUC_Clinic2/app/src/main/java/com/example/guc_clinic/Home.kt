package com.example.guc_clinic

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var btnProfile: Button
    private lateinit var btnMap: Button
    private lateinit var textViewUserEmail: TextView

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        auth = FirebaseAuth.getInstance()
        btnProfile = findViewById(R.id.btn_profile)
        btnMap = findViewById(R.id.btn_map)
        textViewUserEmail = findViewById(R.id.user_email)

        val user = auth.currentUser
        textViewUserEmail.text = "Welcome, ${user?.email}"

        btnProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        btnMap.setOnClickListener {
            startActivity(Intent(this, MapActivity::class.java))
        }
    }
}
