package com.example.guc_clinic

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var textViewEmail: TextView
    private lateinit var editTextExtraData: EditText
    private lateinit var buttonSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        textViewEmail = findViewById(R.id.user_email)
        editTextExtraData = findViewById(R.id.extra_data)
        buttonSave = findViewById(R.id.btn_save)

        val user = auth.currentUser
        textViewEmail.text = user?.email

        buttonSave.setOnClickListener {
            saveExtraData()
        }
    }

    private fun saveExtraData() {
        val extraData = editTextExtraData.text.toString()
        val userId = auth.currentUser?.uid

        if (userId != null && extraData.isNotEmpty()) {
            val userData = hashMapOf("extraData" to extraData)

            db.collection("users").document(userId)
                .set(userData)
                .addOnSuccessListener {
                    Toast.makeText(this, "Data saved successfully!", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Error saving data: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "Please enter some data", Toast.LENGTH_SHORT).show()
        }
    }
}
